#import "LockWatchKit.h"
#import <sqlite3.h>

@interface LWKActivityDataProvider : NSObject

+ (NSDictionary*)activityData;

@end
