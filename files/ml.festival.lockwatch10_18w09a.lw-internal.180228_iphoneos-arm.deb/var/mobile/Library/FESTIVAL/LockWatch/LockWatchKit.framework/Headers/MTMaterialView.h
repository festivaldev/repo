@interface MTMaterialView : UIView

+(id)materialViewWithRecipe:(long long)arg1 options:(unsigned long long)arg2;
-(void)_setCornerRadius:(double)arg1 ;
-(void)_setContinuousCornerRadius:(double)arg1 ;

@end
